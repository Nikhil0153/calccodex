let history = '';
let current = '0';
let operation = null;

function updateDisplay() {
  document.getElementById('history').innerText = history;
  document.getElementById('result').innerText = current;
}

function appendNumber(number) {
  if (current === '0' || operation) {
    current = number.toString();
    operation = null;
  } else {
    current += number;
  }
  updateDisplay();
}

function appendOperation(op) {
  if (current !== '') {
    if (op === '+/-') {
      current = (parseFloat(current) * -1).toString();
    } else {
      history = current + ' ' + op;
      current = '';
      operation = op;
    }
  }
  updateDisplay();
}

function clearDisplay() {
  history = '';
  current = '0';
  operation = null;
  updateDisplay();
}

function calculate() {
  if (history && current) {
    let result;
    const [prev, op] = history.split(' ');
    const curr = parseFloat(current);

    switch (op) {
      case '+': result = parseFloat(prev) + curr; break;
      case '-': result = parseFloat(prev) - curr; break;
      case '*': result = parseFloat(prev) * curr; break;
      case '/': result = curr !== 0 ? parseFloat(prev) / curr : 'Error'; break;
      case '%': result = parseFloat(prev) % curr; break;
    }

    current = result.toString();
    history = '';
    operation = null;
    updateDisplay();
  }
}

// Add Keyboard Support
document.addEventListener('keydown', (event) => {
    const key = event.key; // Get the pressed key
  
    if (!isNaN(key)) {
      // If the key is a number (0-9)
      appendNumber(key);
    } else if (key === '+') {
      appendOperation('+');
    } else if (key === '-') {
      appendOperation('-');
    } else if (key === '*') {
      appendOperation('*');
    } else if (key === '/') {
      appendOperation('/');
    } else if (key === '%') {
      appendOperation('%');
    } else if (key === 'Enter' || key === '=') {
      // Handle "Enter" or "=" for calculation
      calculate();
    } else if (key === 'Escape' || key === 'C' || key === 'c') {
      // Handle "Escape" or "C" for clearing
      clearDisplay();
    } else if (key === '.') {
      // Handle decimal point
      appendOperation('.');
    } else if (key === 'Backspace') {
      // Handle backspace for deleting the last character
      current = current.slice(0, -1) || '0'; // Remove the last character
      updateDisplay();
    }
  });